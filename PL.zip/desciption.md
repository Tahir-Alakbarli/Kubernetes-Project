Bank Heist (50 points)
The task is to create a simplified bank heist simulation program, with the help of the following subtasks.

A team of crooks plans to rob a series of vaults. Each crook has a different specialization (a hacker who can break electronic locks), and each vault is protected by a different security level. The heist planner orchestrates the whole operation, sending crooks to vaults one after another while time is running out.

1. Loot and Crooks: LootType, Loot, Crook, Hacker (21 points)
Loot class and its supporting LootType enum (1 + 4 + 1 + 1 = 7 points)
The LootType enum defines the possible types of a piece of loot. The constructor in the Loot class should initialize the lootName, lootType and lootValue fields. The Loot class should also support an equality check, whereby two pieces of loot are considered equal if all three of the above-mentioned fields are equal.

Testing the Loot class (1 + 2 + 1 + 1 = 5 points)
lootConstructorTest tests that the class's constructor initializes its fields properly.
lootEqualityCheckTest is a ParameterizedTest that should test the equality check of the Loot class.
Crook and Hacker classes (2 + 1 + 1 + 1 + 1 + 1 = 7 points)
Crook is the common superclass of every member of the heist team. The constructor in the Crook class should initialize the crookName and skillLevel fields. The Crook class's textual representation should be Crook <crookName> with skill <skillLevel>. Example: a crook called "John Doe" with skill level 5 has the textual representation: Crook John Doe with skill 5

The increaseSkill method should increase the crook's skillLevel by the given amount.

The canBeat method should return true if the crook's skillLevel is greater than or equal to the given securityLevel, otherwise false.

The Hacker class is a subclass of Crook, with an additional hackingTool field of type String. The Hacker's constructor should initialize all three fields. The Hacker class should override the textual representation, which should be Hacker <crookName> with skill <skillLevel>, using <hackingTool>. Example: Hacker Alice with skill 7, using Laptop

The crackBonus method should return the sum of the hacker's skillLevel and the length of the hackingTool string. Example: a hacker with skill level 7 and tool "Laptop" has a crackBonus of 7 + 6 = 13.

The upgradeTool method should replace the hacker's hackingTool with the given newTool.

Testing the Crook and Hacker classes (1 + 1 = 2 points)
Each of the following test classes is worth 1 point in total (covering all the listed test methods together).

CrookTest: increaseSkillTest, canBeatTest.
HackerTest: hackerTextualRepresentationTest, crackBonusTest, upgradeToolTest.
2. Vaults: Stealable, Vault, AlarmTriggeredException (15 points)
Vault class and its supporting classes (1 + 1 + 1 + 1 + 2 + 1 + 1 + 1 + 1 = 10 points)
The AlarmTriggeredException is a simple exception type. The only method in the Stealable interface will be implemented in the Vault class. The constructor in the Vault class should initialize the securityLevel and contents fields. contents should initially be empty.

The getContents method should return a copy of the vault's contents (so the caller cannot modify the vault's internal list).

The Vault class should provide an addLoot method:

addLoot(Loot... loots) should add every piece of loot in the array to contents.
The getTotalValue method should return the sum of the values of all loot currently in contents, without modifying the vault.

The removeLoot method should remove the first occurrence of the given loot from contents and return true if it was found and removed, otherwise return false.

The steal method should work as follows:

If the crook parameter cannot beat the vault's securityLevel, the method should throw an AlarmTriggeredException.
Otherwise, the method should compute the total value of all loot in contents, then clear contents, and return the computed total.
Testing the Vault class (1 + 1 + 1 + 1 + 1 = 5 points)
vaultRemoveLootTest tests that removeLoot correctly removes a piece of loot and returns the right result.
vaultStealTest tests whether steal returns the correct total value when the crook's skill is high enough, and whether the vault's contents are cleared afterwards.
vaultAlarmTest tests whether the proper exception is thrown when the crook's skill is too low.
3. Heist Planner: HeistPlanner, OutOfTimeException (10 points)
HeistPlanner class and its supporting OutOfTimeException (1 + 5 = 6 points)
The OutOfTimeException is a simple exception type. The constructor in the HeistPlanner class should initialize the crook, vaults and timeRemaining fields. The totalLoot field should initially be 0.

The getTotalLoot method should return the value of the totalLoot field.
The executeHeist method should work as follows:
The planner goes through the vaults list in order. For each vault, it sends the crook to attempt the steal.
If the steal is successful, add the returned amount to totalLoot, and decrement timeRemaining by 1.
If the steal throws an AlarmTriggeredException, the vault is skipped (no change to totalLoot), but timeRemaining is still decremented by 1 (the alarm wastes time too).
If at any point during the heist timeRemaining reaches 0 before all vaults have been processed, the method should throw an OutOfTimeException.
Testing the HeistPlanner class (2 + 2 = 4 points)
heistSuccessTest tests a complete successful heist:
Create one Crook, one Vault (with security level the crook can beat), and add a piece of Loot to the vault.
Create a HeistPlanner with enough time.
Check that totalLoot is initially 0.
Call executeHeist.
Check that totalLoot equals the value of the loot.
heistOutOfTimeTest tests the OutOfTimeException case:
Create one crook, two vaults (both with security low enough to be beaten), and a HeistPlanner with timeRemaining = 1.
Verify that calling executeHeist throws an OutOfTimeException.