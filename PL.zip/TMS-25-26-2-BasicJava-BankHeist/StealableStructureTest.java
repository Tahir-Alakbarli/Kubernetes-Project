import check.*;
import static check.Use.*;

import module org.junit.jupiter;

@BeforeAll
public static void init() {
    // usedLang = Lang.EN; // uncomment to enforce the message language
    Use.theInterface("bankheist.vault.Stealable")
       .thatIs(INSTANCE_LEVEL, NOT_IMPLEMENTED, MODIFIABLE, VISIBLE_TO_ALL)
       .info("Implemented by `Vault`. Declares the `steal` operation that a crook can perform.");
}

@Test
public void methodSteal() {
    it.hasMethod("steal", withParams("crook: bankheist.crook.Crook"))
      .that(hasUsualModifiers())
      .thatReturns("int")
      .thatThrows("bankheist.utils.AlarmTriggeredException")
      .info("""
          Returns rhe total value of all loot stolen from the vault.
          Throws `AlarmTriggeredException` if the crook's skill level is not high
          enough to beat the vault's security level.
      """);
}

void main() {}


