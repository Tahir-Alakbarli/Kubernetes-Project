import check.*;
import static check.Use.*;

import module org.junit.jupiter;

@BeforeAll
public static void init() {
    // usedLang = Lang.EN; // uncomment to enforce the message language
    Use.theClass("bankheist.crook.Crook")
       .that(hasUsualModifiers())
       .info("The common superclass of every member of the heist team.");
}

@Test
public void fieldCrookName() {
    it.hasField("crookName: String")
      .thatIs(INSTANCE_LEVEL, FULLY_IMPLEMENTED, MODIFIABLE, VISIBLE_TO_SUBCLASSES)
      .thatHas(GETTER)
      .thatHasNo(SETTER);
}

@Test
public void fieldSkillLevel() {
    it.hasField("skillLevel: int")
      .thatIs(INSTANCE_LEVEL, FULLY_IMPLEMENTED, MODIFIABLE, VISIBLE_TO_SUBCLASSES)
      .thatHas(GETTER)
      .thatHasNo(SETTER);
}

@Test
public void constructor() {
    it.hasConstructor(withArgsLikeAllFields())
      .thatIs(VISIBLE_TO_ALL);
}

@Test
public void methodIncreaseSkill() {
    it.hasMethod("increaseSkill", withParams("amount: int"))
      .that(hasUsualModifiers())
      .thatReturnsNothing()
      .info("Increases the crook's `skillLevel` by the given amount.")
      .testWith(testCase("increaseSkillTest"), "Tests that `increaseSkill` correctly increases the crook's skill level.");
}

@Test
public void methodCanBeat() {
    it.hasMethod("canBeat", withParams("securityLevel: int"))
      .that(hasUsualModifiers())
      .thatReturns("boolean")
      .info("Returns `true` if the crook's `skillLevel` is greater than or equal to `securityLevel`,")
      .info("otherwise `false`.")
      .testWith(testCase("canBeatTest"), "Tests that `canBeat` returns the correct result for security levels above and below the crook's skill.");
}

@Test
public void text() {
    it.has(TEXTUAL_REPRESENTATION)
      .info("""
          Example: a crook called "John Doe" with skill level 5
          Crook John Doe with skill 5
      """);
}

void main() {}


