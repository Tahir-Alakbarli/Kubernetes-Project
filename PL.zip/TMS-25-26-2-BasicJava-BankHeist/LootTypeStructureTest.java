import check.*;
import static check.Use.*;

import module org.junit.jupiter;

@Test
public void elements() {
    Use.theEnum("bankheist.utils.LootType")
       .ofEnumElements("CASH", "JEWELRY", "ARTIFACT", "GOLD")
       .that(hasUsualModifiers());
}

void main() {}


