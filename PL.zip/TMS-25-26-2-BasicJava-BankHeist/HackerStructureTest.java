import check.*;
import static check.Use.*;

import module org.junit.jupiter;

@BeforeAll
public static void init() {
    // usedLang = Lang.EN; // uncomment to enforce the message language
    Use.theClass("bankheist.crook.Hacker", withParent("bankheist.crook.Crook"))
       .that(hasUsualModifiers())
       .info("A subclass of `Crook` specializing in breaking electronic locks.");
}

@Test
public void fieldHackingTool() {
    it.hasField("hackingTool: String")
      .that(hasUsualModifiers())
      .thatHas(GETTER)
      .thatHasNo(SETTER);
}

@Test
public void constructor() {
    it.hasConstructor(withParams("crookName: String", "skillLevel: int", "hackingTool: String"))
      .thatIs(VISIBLE_TO_ALL);
}

@Test
public void methodCrackBonus() {
    it.hasMethod("crackBonus", withNoParams())
      .that(hasUsualModifiers())
      .thatReturns("int")
      .info("Returns the sum of the hacker's `skillLevel` and the length of the `hackingTool` string.")
      .info("Example: a hacker with skill level 7 and tool \'Laptop\' has a crackBonus of 7 + 6 = 13.")
      .testWith(testCase("crackBonusTest"), "Tests that `crackBonus` returns the correct sum.");
}

@Test
public void methodUpgradeTool() {
    it.hasMethod("upgradeTool", withParams("newTool: String"))
      .that(hasUsualModifiers())
      .thatReturnsNothing()
      .info("Replaces the hacker's `hackingTool` with `newTool`.")
      .testWith(testCase("upgradeToolTest"), "Tests that `upgradeTool` correctly replaces the hacker's tool.");
}

@Test
public void text() {
    it.has(TEXTUAL_REPRESENTATION)
      .info("Example: Hacker Alice with skill 7, using Laptop")
      .testWith(testCase("hackerTextualRepresentationTest"), "The textual representation of a `Hacker` is correct.");
}

void main() {}


