import check.*;
import static check.Use.*;

import module org.junit.jupiter;

@BeforeAll
public static void init() {
    // usedLang = Lang.EN; // uncomment to enforce the message language
    Use.theClass("bankheist.vault.Vault", withInterface("bankheist.vault.Stealable"))
       .that(hasUsualModifiers())
       .info("Represents a bank vault protected by a security level and containing a list of loot.");
}

@Test
public void fieldSecurityLevel() {
    it.hasField("securityLevel: int")
      .that(hasUsualModifiers())
      .thatHas(GETTER)
      .thatHasNo(SETTER);
}

@Test
public void fieldContents() {
    it.hasField("contents: List of bankheist.loot.Loot")
      .that(hasUsualModifiers())
      .thatHas(GETTER)
      .thatHasNo(SETTER)
      .info("Initially empty. Accessible only through `getContents()` which returns a copy.");
}

@Test
public void constructor() {
    it.hasConstructor(withArgsLikeFields("securityLevel"))
      .thatIs(VISIBLE_TO_ALL)
      .info("""
          Initializes the vault with the given security level and an empty contents list.
          `contents` should initially be empty.
      """);
}

@Test
public void methodGetTotalValue() {
    it.hasMethod("getTotalValue", withNoParams())
      .that(hasUsualModifiers())
      .thatReturns("int")
      .info("""
          Returns the sum of the values of all loot currently in `contents`,
          without modifying the vault.
      """);
}

@Test
public void methodRemoveLoot() {
    it.hasMethod("removeLoot", withParams("loot: bankheist.loot.Loot"))
      .that(hasUsualModifiers())
      .thatReturns("boolean")
      .info("Removes the first occurrence of `loot` from `contents`.")
      .info("Returns `true` if the loot was found and removed, otherwise `false`.")
      .testWith(testCase("vaultRemoveLootTest"), "Tests that `removeLoot` correctly removes a piece of loot and returns the right result.");
}

@Test
public void methodAddLoot() {
    it.hasMethod("addLoot", withParams("loot: array of bankheist.loot.Loot"))
      .that(hasUsualModifiers())
      .thatReturnsNothing()
      .info("Adds every piece of loot in the array to `contents`.");
}

@Test
public void methodSteal() {
    it.hasMethod("steal", withParams("crook: bankheist.crook.Crook"))
      .that(hasUsualModifiers())
      .thatReturns("int")
      .thatThrows("bankheist.utils.AlarmTriggeredException")
      .info("""
          If the `crook` parameter's `skillLevel` is less than the vault's `securityLevel`,
          the method should throw an `AlarmTriggeredException`.
          Otherwise, sum the values of all the loot in `contents`, clear `contents`, and return the sum.
      """)
      .testWith(testCase("vaultStealTest"), "Tests whether `steal` returns the correct total value and clears the vault's contents.")
      .testWith(testCase("vaultAlarmTest"), "Tests whether the proper exception is thrown when the crook's skill is too low.");
}

void main() {}


