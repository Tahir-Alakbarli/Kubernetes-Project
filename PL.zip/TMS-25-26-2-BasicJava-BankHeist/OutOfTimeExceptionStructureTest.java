import check.*;
import static check.Use.*;

import module org.junit.jupiter;

@BeforeAll
public static void init() {
    // usedLang = Lang.EN; // uncomment to enforce the message language
    Use.theUncheckedException("bankheist.utils.OutOfTimeException")
       .that(hasUsualModifiers())
       .info("""
           Thrown by `HeistPlanner.executeHeist()` when `timeRemaining` reaches 0 before all
           vaults have been processed.
       """);
}

@Test
public void constructor() {
    it.hasConstructor(withNoParams())
      .thatIs(VISIBLE_TO_ALL);
}

void main() {}


