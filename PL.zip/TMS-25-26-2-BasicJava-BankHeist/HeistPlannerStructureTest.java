import check.*;
import static check.Use.*;

import module org.junit.jupiter;

@BeforeAll
public static void init() {
    // usedLang = Lang.EN; // uncomment to enforce the message language
    Use.theClass("bankheist.HeistPlanner")
       .that(hasUsualModifiers())
       .info("Orchestrates the heist by sending the crook through each vault in order.");
}

@Test
public void fieldCrook() {
    it.hasField("crook: bankheist.crook.Crook")
      .that(hasUsualModifiers())
      .thatHasNo(GETTER, SETTER);
}

@Test
public void fieldVaults() {
    it.hasField("vaults: List of bankheist.vault.Vault")
      .that(hasUsualModifiers())
      .thatHasNo(GETTER, SETTER);
}

@Test
public void fieldTimeRemaining() {
    it.hasField("timeRemaining: int")
      .that(hasUsualModifiers())
      .thatHas(GETTER)
      .thatHasNo(SETTER);
}

@Test
public void fieldTotalLoot() {
    it.hasField("totalLoot: int")
      .that(hasUsualModifiers())
      .thatHas(GETTER)
      .thatHasNo(SETTER);
}

@Test
public void constructor() {
    it.hasConstructor(withArgsLikeFields("crook", "vaults", "timeRemaining"))
      .thatIs(VISIBLE_TO_ALL)
      .info("Initializes `crew`, `vaults`, and `timeRemaining` from arguments. `totalLoot` starts at 0.");
}

@Test
public void methodExecuteHeist() {
    it.hasMethod("executeHeist", withNoParams())
      .that(hasUsualModifiers())
      .thatReturnsNothing()
      .thatThrows("bankheist.utils.OutOfTimeException")
      .info("Goes through `vaults` in order, sending the `crook` to attempt each steal.")
      .info("On success: adds the returned amount to `totalLoot` and decrements `timeRemaining` by 1.")
      .info("On `AlarmTriggeredException`: skips the vault but still decrements `timeRemaining` by 1.")
      .info("If at any point `timeRemaining` reaches 0 before all vaults have been processed, throw `OutOfTimeException`.")
      .testWith(testCase("heistSuccessTest"), "Tests a complete successful heist where `totalLoot` equals the value of the loot after execution.")
      .testWith(testCase("heistOutOfTimeTest"), "Tests that `OutOfTimeException` is thrown when `timeRemaining` is exhausted before all vaults are processed.");
}

void main() {}


