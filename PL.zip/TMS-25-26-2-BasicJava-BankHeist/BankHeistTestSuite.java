import org.junit.platform.suite.api.*;
import org.junit.jupiter.api.*;

@SelectClasses({
    BankHeistTestSuite.StructuralTests.class,
    BankHeistTestSuite.FunctionalTests.class,
})
@Suite(failIfNoTests=false) public class BankHeistTestSuite {
    @SelectClasses({
        LootTypeStructureTest.class,
        LootStructureTest.class,
        CrookStructureTest.class,
        HackerStructureTest.class,
        AlarmTriggeredExceptionStructureTest.class,
        OutOfTimeExceptionStructureTest.class,
        StealableStructureTest.class,
        VaultStructureTest.class,
        HeistPlannerStructureTest.class,
    })
    @Suite(failIfNoTests=false) @Tag("structural") public static class StructuralTests {}

    @SelectClasses({
        bankheist.loot.LootTest.class,
        bankheist.crook.CrookTest.class,
        bankheist.crook.HackerTest.class,
        bankheist.vault.VaultTest.class,
        bankheist.HeistPlannerTest.class,
    })
    @Suite(failIfNoTests=false) @Tag("functional") public static class FunctionalTests {}
}
