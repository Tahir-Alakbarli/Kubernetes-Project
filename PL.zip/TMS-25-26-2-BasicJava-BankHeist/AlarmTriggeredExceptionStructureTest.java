import check.*;
import static check.Use.*;

import module org.junit.jupiter;

@BeforeAll
public static void init() {
    // usedLang = Lang.EN; // uncomment to enforce the message language
    Use.theUncheckedException("bankheist.utils.AlarmTriggeredException")
       .that(hasUsualModifiers())
       .info("""
           Thrown when a crook's skill level is not high enough to beat a vault's security level.
           Signals that the alarm was triggered during a steal attempt.
       """);
}

@Test
public void constructor() {
    it.hasConstructor(withNoParams())
      .thatIs(VISIBLE_TO_ALL);
}

void main() {}


