import check.*;
import static check.Use.*;

import module org.junit.jupiter;

@BeforeAll
public static void init() {
    // usedLang = Lang.EN; // uncomment to enforce the message language
    Use.theClass("bankheist.loot.Loot")
       .that(hasUsualModifiers())
       .info("Represents a piece of loot with a name, type, and monetary value.");
}

@Test
public void fieldLootName() {
    it.hasField("lootName: String")
      .that(hasUsualModifiers())
      .thatHas(GETTER)
      .thatHasNo(SETTER);
}

@Test
public void fieldLootType() {
    it.hasField("lootType: bankheist.utils.LootType")
      .that(hasUsualModifiers())
      .thatHas(GETTER)
      .thatHasNo(SETTER);
}

@Test
public void fieldLootValue() {
    it.hasField("lootValue: int")
      .that(hasUsualModifiers())
      .thatHas(GETTER)
      .thatHasNo(SETTER);
}

@Test
public void constructor() {
    it.hasConstructor(withArgsLikeAllFields())
      .thatIs(VISIBLE_TO_ALL)
      .testWith(testCase("lootConstructorTest"), "The class's constructor initializes its fields properly.");
}

@Test
public void eq() {
    it.has(EQUALITY_CHECK)
      .info("Two pieces of loot are equal if `lootName`, `lootType`, and `lootValue` are all equal.")
      .testWith(testCase("lootEqualityCheckTest"), "is a ParameterizedTest that should test the equality check of the `Loot` class.");
}

void main() {}


